<html>
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
      <?php 
    echo "<div>Código: " . $_POST['tCodigo'] . "</div>";
     ?> 
       
    </body>
</html>
