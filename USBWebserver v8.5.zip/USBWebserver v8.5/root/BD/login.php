<html>
<head>
	<title>Exemplo BD</title>
</head>
<body>
	<form action="valida_login.php" method="post">
		<fieldset>
		<legend>Tela de login</legend>
		<label>Usu�rio</label>
		<input type="text" name = "txtUsuario" id="txtUsuario" /> <br/>
		<label>Senha</label>
		<input type="password" name = "txtSenha" id="txtSenha" /> <br/>
		<input type="submit" value="Logar"/>
		</fieldset>		
	</form>
</body>
</html>