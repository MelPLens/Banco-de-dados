<?php
$conn = mysql_connect("localhost","root","usbw");
    mysql_select_db("agenda",$conn);
    mysql_connect();
?>
