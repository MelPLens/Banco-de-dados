<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>
        <a href="cadUsuario.php">Cadastrar Usuário</a>
        <a href="listaUsuario.php">Listar Usuário</a>
    </body>
</html>
