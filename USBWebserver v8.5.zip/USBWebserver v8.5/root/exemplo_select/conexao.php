<?php
    $conn = mysql_connect("localhost","root","usbw");
    mysql_select_db("vendas",$conn);
    mysql_connect();
?>

